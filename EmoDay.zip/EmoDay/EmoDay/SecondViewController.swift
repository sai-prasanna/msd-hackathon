//
//  SecondViewController.swift
//  EmoDay
//
//  Created by Sai Prasanna on 29/04/17.
//  Copyright © 2017 Sai Prasanna. All rights reserved.
//

import UIKit
import Pantry

class SecondViewController: UIViewController, UITableView, UITableViewDataSource {
    
    let tableView = UITableView()
    var records = [Record]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height)
        tableView.delegate = self
        tableView.register(CustomCell.self, forCellReuseIdentifier: "cell")
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // Do any additional setup after loading the view, typically from a nib.
        if let records:[Record] = Pantry.unpack("records") {
            self.records = records
            tableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return records.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomCell
        let record = records[indexPath.row]
        
        cell.date.text = record.date.description
        cell.imageView1.image = UIImage(data: record.data as Data)!
        cell.textLabel1.text = record.text
        cell.imageticon.text = record.photoEmotion.emoticon
        cell.textoticon.text = record.textEmotion.emoticon
        return cell
    }
    
}

class CustomCell: UITableViewCell {
    
    let imageView1 = UIImageView()
    let textLabel1 = UILabel()
    let imageticon = UILabel()
    let textoticon = UILabel()
    let date = UILabel()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(imageView1)
        contentView.addSubview(date)
        contentView.addSubview(textLabel1)
        contentView.addSubview(imageticon)
        contentView.addSubview(textoticon)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        date.frame = CGRect(x: 5, y: 5, width: 100, height: 15)
        imageView1.frame = CGRect(x: 5, y: 20, width: 80, height: 80)
        textLabel1.frame = CGRect(x: 100, y: 40, width: contentView.bounds.width, height: 40)
        imageticon.frame = CGRect(x: 5, y: 100, width: 80, height: 80)
        textoticon.frame = CGRect(x: contentView.bounds.width - 85, y: 100, width: 80, height: 80)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
